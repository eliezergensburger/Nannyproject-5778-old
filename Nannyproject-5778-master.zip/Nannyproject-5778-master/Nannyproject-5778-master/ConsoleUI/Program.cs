﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using BE;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            int option = 0;
            do
            {
                Console.WriteLine("ma ata rotze vreech");
                try
                {
                    option = Int32.Parse(Console.ReadLine());
                }
                catch (Exception e)
                {
                    Console.WriteLine("kuku was here");
                    throw e;
                }

                switch (option)
                {
                    case 0:
                        break;
                    case 1:
                        try
                        {
                            Mother imma = NewMother();
                            addMother(imma);
                        }
                        catch (Exception baaya)
                        {
                            Console.WriteLine(baaya.Message);
                        }
                        break;
                    case 2:
                        showAllMothers();
                        break;

                }

            } while (option != 0);
            Console.ReadLine();
        }

        private static Mother NewMother()
        {
            return new Mother
            {
                ID = 37,
                FirstName = "Mamme",
                LastName = "Sheli",
                Address = "Ha-Va'ad ha-Le'umi St 21, Jerusalem",
                Location = "Yehuda HaMaccabi St 5, Jerusalem",
                CellPhone = "052222222",
                WantedDays = new bool[6] { true, true, true, true, true, false },
                Days = new List<Day>(6)
                            {
                                new Day {  StartDay = new Time(7), EndDay = new Time(16)},
                                new Day {  StartDay = new Time(8), EndDay = new Time(16)},
                                new Day {  StartDay = new Time(7,30), EndDay = new Time(13)},
                                new Day {  StartDay = new Time(8), EndDay = new Time(16)},
                                new Day {  StartDay = new Time(8), EndDay = new Time(17)},
                                null,
                            }
            };
        }

        private static void addMother(Mother mammele)
        {
            BL.FactorySingletonBL.getInstance.addMother(mammele);
         }
        private static void showAllMothers()
        {
            List<Mother> immaot = BL.FactorySingletonBL.getInstance.getAllMothers();
            foreach (var m in immaot)
            {
                Console.WriteLine(m);
            }

        }

    }
}
