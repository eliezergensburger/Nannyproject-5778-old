﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class Day
    {
        public Time StartDay { get; set; }
        public Time EndDay { get; set; }
    }
}
