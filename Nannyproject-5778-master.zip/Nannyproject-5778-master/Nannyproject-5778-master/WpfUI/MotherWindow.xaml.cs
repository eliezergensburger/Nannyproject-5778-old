﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfUI
{
    /// <summary>
    /// Interaction logic for MotherWindow.xaml
    /// </summary>
    public partial class MotherWindow : Window
    {
        public MotherWindow()
        {
            InitializeComponent();
        }

        private void addMotherBtn_Click(object sender, RoutedEventArgs e)
        {
            AddMotherWindow wnd = new AddMotherWindow();
            bool? result = wnd.ShowDialog();
            if (result== false)
            {
                MessageBox.Show("add mother cancelled");
            }
        }

        private void getAllMotherBtn_Click(object sender, RoutedEventArgs e)
        {
            ShowAllMothersWindow wnd = new ShowAllMothersWindow();
            wnd.Show();
        }
    }
}
