﻿using BE;
using BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfUI
{
    /// <summary>
    /// Interaction logic for AddMotherWindow.xaml
    /// </summary>
    public partial class AddMotherWindow : Window
    {
        Mother sabalit;
        public AddMotherWindow()
        {
            InitializeComponent();
            sabalit = new Mother();
            DataContext = sabalit;
        }

         private void OKBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                sabalit.ID = Int32.Parse(iDTextBox.Text);
                FactorySingletonBL.getInstance.addMother(sabalit);
                sabalit = new Mother();
                DataContext = sabalit;
                DialogResult = true;
                this.Close();
            }
            catch (Exception problem)
            {
                MessageBox.Show(problem.Message,"kuku was here",  MessageBoxButton.OK,MessageBoxImage.Error);
            }
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
