﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;

namespace DAL
{
    public class Dal_List : IDal
    {
        public int addMother(Mother m)
        {
            Mother kayemet = getMotherByID(m.ID);
            if(kayemet != null)
            {
                throw new Exception("mother already exist");
            }
            DS.DataSource.Mothers.Add(m.clone());
            return m.ID;
        }

        public bool removeMother(Mother m)
        {
            //  Mother lesheavar = getMotherByID(m.ID);
            //  return DS.DataSource.Mothers.Remove(lesheavar); 
            return (DS.DataSource.Mothers.RemoveAll(mi => mi.ID == m.ID) == 1);
        }

        public IEnumerable<Mother> getAllMothers()
        {
            List<Mother> mothers = new List<Mother>();
            foreach (var m in DS.DataSource.Mothers)
            {
                mothers.Add(m.clone());
            }
            return mothers.AsEnumerable();
        }
        private Mother getMotherByID(int id)
        {
            Mother result = null;
            foreach (var item in DS.DataSource.Mothers)
            {
                if(item.ID== id)
                {
                    result = item;
                    break;
                }
            }
            return result;
        }
    }
}
