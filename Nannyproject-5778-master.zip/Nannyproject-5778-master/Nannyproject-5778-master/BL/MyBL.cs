﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using DAL;

namespace BL
{
    public class MyBL:Ibl
    {
        private  IDal dal;
        public MyBL()
        {
             dal = DAL.FactorysingletonDal.getInstance;
        }
        public int addMother(Mother m)
        {
            return dal.addMother(m);
        }

        public bool removeMother(Mother m)
        {
            return dal.removeMother(m);
        }

        public List<Mother> getAllMothers()
        {
             return dal.getAllMothers().ToList();
        }
    }
}
